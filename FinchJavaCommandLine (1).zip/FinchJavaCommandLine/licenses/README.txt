
TeRK (http://code.google.com/p/terk/)

, The Finch software package, the CREATE Lab Commons libraries, and the TeRK libraries are all distributed under the terms 
of the GNU GPL v2 license.  Please see the separate license files for details on licensing for the following libraries:



* Apache Commons Lang (http://commons.apache.org/lang/)


* CREATE Lab Commons (https://code.google.com/p/create-lab-commons/)


* FreeTTS (http://freetts.sourceforge.net/)
  - Used to synthesize speech from text.


* JDom (http://www.jdom.org/)
  - Used for xml parsing by RSS Readers.


* JNA (https://jna.dev.java.net/)
  - Used to access native OS USB drivers to communicate over USB with Finch.


* Log4j (http://logging.apache.org/log4j/1.2/)
  - Used to log Finch software errors or events.


* LTI-Civil (http://lti-civil.org/)
  - Used to interface with webcams.


* Rome (https://rome.dev.java.net/)
  - Used for RSS Readers.


* Swing Layout (https://swing-layout.dev.java.net/)


